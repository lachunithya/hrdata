from django.db import models


class Employee(models.Model):
    emp_id = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    gender = models.CharField(max_length=10)
    dep=models.CharField(max_length=50)
    func=models.CharField(max_length=50)
    month = models.CharField(max_length=20)
    hire_date = models.DateField()
    left_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20)
    left_month = models.CharField(max_length=20, null=True, blank=True)
    labour_type = models.CharField(max_length=20)
    location = models.CharField(max_length=100)
    timestamp= models.DateTimeField()

class Upload(models.Model):
    file = models.FileField(upload_to='uploads/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    