from django.db.models import Count
from django.db.models.functions import TruncMonth, TruncYear
from django.shortcuts import render
import json
from .models import Employee
import calendar
from datetime import date, datetime, timedelta
import calendar
from django.db.models import Q
from django.shortcuts import render
from django.db.models import Count
from .models import Employee
from datetime import datetime, timedelta
import calendar
import json
from django.core.serializers.json import DjangoJSONEncoder
from django.db.models import Sum, IntegerField, Case, When
from django.contrib.auth.decorators import login_required


@login_required
def chart_data(request):
    # Aggregate data based on hire_date
    hire_data = Employee.objects.annotate(
        truncated_month=TruncMonth('hire_date'),
        truncated_year=TruncYear('hire_date')
    ).values('truncated_month', 'truncated_year').annotate(count=Count('id')).filter(truncated_month__isnull=False, truncated_year__isnull=False)

    # Aggregate data based on left_date
    left_data = Employee.objects.annotate(
        truncated_month=TruncMonth('left_date'),
        truncated_year=TruncYear('left_date')
    ).values('truncated_month', 'truncated_year').annotate(count=Count('id')).filter(truncated_month__isnull=False, truncated_year__isnull=False)

    # Process hire data for Chart.js
    hire_labels = [{'month': d['truncated_month'].strftime('%B'), 'year': d['truncated_year'].year} for d in hire_data]
    hire_counts = [d['count'] for d in hire_data]

    # Process left data for Chart.js
    left_labels = [{'month': d['truncated_month'].strftime('%B'), 'year': d['truncated_year'].year} for d in left_data]
    left_counts = [d['count'] for d in left_data]

    # Prepare data for Chart.js
    chart_data1 = {
        'labels': hire_labels,
        'counts': hire_counts,
    }
    chart_data2 = {
        'labels': left_labels,
        'counts': left_counts,
    }

    return render(request, 'chart.html', {
        'chart_data1': json.dumps(chart_data1),
        'chart_data2': json.dumps(chart_data2)
    })

@login_required
def list(request):
    emp = Employee.objects.all()
    return render(request, 'list.html', {'emp':emp})

def data(request):
    # Define the range of months to report on, typically the current year
    year = date.today().year
    months = [date(year, m, 1) for m in range(1, 13)]

    # Aggregate data for active employees based on hire_date
    hires = Employee.objects.filter(status='Active', hire_date__year=year).annotate(
        truncated_month=TruncMonth('hire_date')
    ).values('truncated_month').annotate(count=Count('id')).order_by('truncated_month')

    # Aggregate data for employees who left based on left_date
    lefts = Employee.objects.filter(status='Left', left_date__year=year).annotate(
        truncated_month=TruncMonth('left_date')
    ).values('truncated_month').annotate(count=Count('id')).order_by('truncated_month')

    # Prepare chart data
    hire_dict = {data['truncated_month']: data['count'] for data in hires}
    left_dict = {data['truncated_month']: data['count'] for data in lefts}

    labels = [month.strftime('%B') for month in months]
    net_counts = []
    last_net = 0  # Start with 0 or set it to a specific initial value if needed

    for month in months:
        if month in hire_dict or month in left_dict:
            hired = hire_dict.get(month, 0)
            left = left_dict.get(month, 0)
            net_change = hired - left
            last_net += net_change  # Update last known value with net change
        # If month is not present in hire_dict or left_dict, last_net remains unchanged
        net_counts.append(last_net)

    chart_data = {
        'labels': labels,
        'net': net_counts,
    }

    return render(request, 'chart2.html', {'chart_data': json.dumps(chart_data)})

def table(request, selected_year=None):
    if not selected_year:
        selected_year = 2023  # Default to 2023 if selected_year is not provided
    years = [selected_year]  # Only include the selected year in the dropdown

    # Aggregate data for active employees hired in the selected year
    hires = Employee.objects.filter(status='Active', hire_date__year=selected_year).annotate(
        truncated_month=TruncMonth('hire_date')
    ).values('truncated_month').annotate(count=Count('id')).order_by('truncated_month')

    # Aggregate data for employees who left in the selected year
    lefts = Employee.objects.filter(status='Left', left_date__year=selected_year).annotate(
        truncated_month=TruncMonth('left_date')
    ).values('truncated_month').annotate(count=Count('id')).order_by('truncated_month')

    # Prepare dictionaries to hold counts for each month
    hire_dict = {data['truncated_month']: data['count'] for data in hires}
    left_dict = {data['truncated_month']: data['count'] for data in lefts}

    table_data = []
    last_net = 0

    # Loop through each month of the selected year
    for month in range(1, 13):
        truncated_month = date(selected_year, month, 1)

        # Calculate the net hires for the current month (January)
        hired = hire_dict.get(truncated_month, 0)
        left = left_dict.get(truncated_month, 0) if month == 1 else 0  # For January, consider only left in January
        net_change = hired - left

        # Calculate the cumulative net hires from the beginning of the year
        last_net += net_change

        # Append the data for the current month to the table_data list
        table_data.append({
            'month': truncated_month.strftime('%B'),
            'hired': hired,
            'left': left,
            'net': last_net
        })

    return render(request, 'table.html', {'table_data': table_data, 'years': years, 'selected_year': int(selected_year)})


def overall_table1(request):
    hires = Employee.objects.filter(hire_date__year=2023).values('hire_date__year', 'hire_date__month').annotate(
        count=Count('id')
    ).order_by('hire_date__year', 'hire_date__month')

    # Get leaving data for the year 2023
    lefts = Employee.objects.filter(left_date__year=2023).values('left_date__year', 'left_date__month').annotate(
        count=Count('id')
    ).order_by('left_date__year', 'left_date__month')

    # Create dictionaries to store hiring and leaving counts
    hire_dict = {(h['hire_date__year'], h['hire_date__month']): h['count'] for h in hires}
    left_dict = {(l['left_date__year'], l['left_date__month']): l['count'] for l in lefts}

    # Create a list to store monthly data with month names
    monthly_data = []

    # Iterate through each month of the year
    for month_num in range(1, 13):
        month_name = calendar.month_name[month_num]  # Get month name
        hire_count = hire_dict.get((2023, month_num), 0)
        left_count = left_dict.get((2023, month_num), 0)
        monthly_data.append({
            'month': month_name,
            'hires': hire_count,
            'lefts': left_count
        })

    return render(request, 'overall.html', {'monthly_data': monthly_data})



@login_required
def overall_table(request):
    years = range(2010, datetime.now().year + 1)
    selected_year = datetime.now().year
    selected_month = datetime.now().month

    # Default start and end dates
    start_date = date(selected_year, 1, 1)
    end_date = date(selected_year, 12, 31)

    if request.method == 'POST':
        # Get the start and end dates from the form
        start_date_str = request.POST.get('start_date')
        end_date_str = request.POST.get('end_date')

        if start_date_str:
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
        if end_date_str:
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()

    # Get hiring and leaving data within the selected date range
    hires = Employee.objects.filter(hire_date__range=(start_date, end_date)).values('hire_date__year', 'hire_date__month').annotate(
        count=Count('id')
    ).order_by('hire_date__year', 'hire_date__month')
    lefts = Employee.objects.filter(left_date__range=(start_date, end_date)).values('left_date__year', 'left_date__month').annotate(
        count=Count('id')
    ).order_by('left_date__year', 'left_date__month')

    # Create dictionaries to store hiring and leaving counts
    hire_dict = {(h['hire_date__year'], h['hire_date__month']): h['count'] for h in hires}
    left_dict = {(l['left_date__year'], l['left_date__month']): l['count'] for l in lefts}

    # Create a list to store monthly data with month names and active count
    monthly_data = []

    # Get the previous year's end of year active count
    previous_year_end_date = start_date.replace(year=start_date.year - 1, month=12, day=31)
    previous_year_hires = Employee.objects.filter(hire_date__lte=previous_year_end_date).count()
    previous_year_lefts = Employee.objects.filter(left_date__lte=previous_year_end_date).count()
    prev_active_count = previous_year_hires - previous_year_lefts

    # Iterate through each month within the selected date range
    current_date = start_date
    while current_date <= end_date:
        year = current_date.year
        month_num = current_date.month
        month_name = calendar.month_name[month_num]

        # Determine the end of the current month
        if month_num == 12:
            end_of_month = date(year + 1, 1, 1) - timedelta(days=1)
        else:
            end_of_month = date(year, month_num + 1, 1) - timedelta(days=1)

        hire_count = hire_dict.get((year, month_num), 0)
        left_count = left_dict.get((year, month_num), 0)

        active_count = prev_active_count + hire_count - left_count

        monthly_data.append({
            'month': month_name,
            'year': year,
            'hires': hire_count,
            'lefts': left_count,
            'active': active_count
        })

        prev_active_count = active_count

        # Move to the next month
        current_date = end_of_month + timedelta(days=1)

    # Convert monthly data to JSON for passing to JavaScript
    monthly_data_json = json.dumps(monthly_data)

    return render(request, 'overall.html', {
        'monthly_data': monthly_data,
        'monthly_data_json': monthly_data_json,
        'years': years,
        'selected_year': selected_year,
        'selected_month': selected_month,
        'start_date': start_date,
        'end_date': end_date
    })

@login_required
def employee_counts_view(request):
    years = range(2010, datetime.now().year + 1)
    selected_start_date = datetime(datetime.now().year, 1, 1)
    selected_end_date = datetime(datetime.now().year, 12, 31)

    if request.method == 'POST':
        start_date_str = request.POST.get('start_date', selected_start_date.strftime('%Y-%m-%d'))
        end_date_str = request.POST.get('end_date', selected_end_date.strftime('%Y-%m-%d'))
        
        selected_start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
        selected_end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
    
    # Derive the selected year from the start date
    selected_year = selected_start_date.year

    monthly_data = []

    # Get the closing count of the previous year's December
    if selected_year > 2010:
        previous_year_december_end_date = datetime(selected_year - 1, 12, 31)
        last_year_december_closing_count = Employee.objects.filter(
            Q(hire_date__lte=previous_year_december_end_date) & (Q(left_date__isnull=True) | Q(left_date__gte=previous_year_december_end_date))
        ).count()
    else:
        last_year_december_closing_count = 0  # No previous data if starting year is the earliest

    current_date = selected_start_date
    while current_date <= selected_end_date and current_date.year == selected_year:
        month_name = calendar.month_name[current_date.month]
        
        start_date = current_date.replace(day=1)
        end_date = (start_date + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        if end_date > selected_end_date:
            end_date = selected_end_date
        
        # Query to get the count of employees hired on or before the first day of the month
        if current_date.month == 1:
            opening_count = last_year_december_closing_count
        else:
            opening_count = Employee.objects.filter(
                Q(hire_date__lte=start_date) & (Q(left_date__isnull=True) | Q(left_date__gte=start_date))
            ).count()
        
        # Query to get the count of employees active on the last day of the month
        closing_count = Employee.objects.filter(
            Q(hire_date__lte=end_date) & (Q(left_date__isnull=True) | Q(left_date__gte=end_date))
        ).count()

        # Calculate average count for the month
        avg_count = (opening_count + closing_count) / 2

        monthly_data.append({
            'month': month_name,
            'opening_count': opening_count,
            'closing_count': closing_count,
            'avg_count': avg_count
        })

        # Move to the next month
        current_date = (current_date + timedelta(days=32)).replace(day=1)

    monthly_data_json = json.dumps(monthly_data)

    return render(request, 'open_close.html', {
        'monthly_data': monthly_data,
        'monthly_data_json': monthly_data_json,
        'years': years,
        'selected_year': selected_year,
        'selected_start_date': selected_start_date,
        'selected_end_date': selected_end_date
    })


@login_required
def dep_summary(request):
    years = range(2010, datetime.now().year + 1)  # Generate years from 2010 to current year
    selected_year = datetime.now().year  # Default to current year

    # Initialize dep_total_count to an empty queryset
    dep_total_count = Employee.objects.none()

    if request.method == 'POST':
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')

        if start_date and end_date:
            # Parse dates from string to datetime objects
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
            end_date = datetime.strptime(end_date, '%Y-%m-%d')

            # Query data for the selected date range
            dep_total_count = Employee.objects.filter(hire_date__range=[start_date, end_date]).values('dep').annotate(total_count=Count('id'))

    # Calculate total_departments
    total_departments = dep_total_count.count()

    # Rest of your code...

    # Query to get function-wise total count within each department
    func_total_count = []
    all_functions = set()  # To store all unique function names
    for dep_item in dep_total_count:
        dep_item['func_counts'] = Employee.objects.filter(dep=dep_item['dep'], hire_date__range=[start_date, end_date]).values('func').annotate(
            total_count=Count('id'),
            male_count=Sum(Case(When(gender='male', then=1), default=0, output_field=IntegerField())),
            female_count=Sum(Case(When(gender='female', then=1), default=0, output_field=IntegerField()))
        )
        func_total_count.append(dep_item)
        # Collect all function names for this department
        for func_item in dep_item['func_counts']:
            all_functions.add(func_item['func'])

    # Collect counts for all functions across all departments
    function_counts = {func: sum(Employee.objects.filter(func=func, hire_date__range=[start_date, end_date]).values_list('id', flat=True)) for func in all_functions}

    # Calculate male and female percentages
    for dep_item in func_total_count:
        for func_item in dep_item['func_counts']:
            total_count = func_item['total_count']
            male_count = func_item['male_count']
            female_count = func_item['female_count']
            func_item['male_percentage'] = (male_count / total_count) * 100 if total_count != 0 else 0
            func_item['female_percentage'] = (female_count / total_count) * 100 if total_count != 0 else 0

    return render(request, 'dep.html', {
        'dep_total_count': dep_total_count,
        'func_total_count': func_total_count,
        'total_departments': total_departments,
        'function_counts': function_counts,
        'years': years,
        'selected_year': selected_year,
    })