

# urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('labor-status-graph/', views.chart_data, name='labor_status_graph'),
    
    # Add other URL patterns as needed
]
