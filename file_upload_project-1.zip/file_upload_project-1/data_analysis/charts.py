from admincharts.models import Chart
from django.db.models import Count
from.models import Employee

class EmployeeStatusChart(Chart):
    model = Employee
    chart_type = 'bar'
    fields = ['status', 'labour_type']
    aggregate = Count('id')
    title = 'Employee Status by Labour Type'
    labels = ['Status', 'Labour Type', 'Count']
    date_field = 'hire_date'
    date_format = '%Y'
    group_by = 'year'