from django.contrib import admin
from .models import Employee
from import_export.admin import ImportExportModelAdmin


class EmployeeAdmin(ImportExportModelAdmin, admin.ModelAdmin):
 list_display = ['id', 'name', 'gender','dep','func', 'month', 'hire_date', 'left_date', 'status', 'left_month', 'labour_type', 'location']
admin.site.register(Employee,EmployeeAdmin)



