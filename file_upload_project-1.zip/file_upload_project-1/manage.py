import os
import sys
from cryptography.fernet import Fernet, InvalidToken

def decrypt_project(key_file_path, project_dir):
    with open(key_file_path, "rb") as f:
        key = f.read()
    f = Fernet(key)
    for root, dirs, files in os.walk(project_dir):
        for file in files:
            file_path = os.path.join(root, file)
            with open(file_path, "rb") as file:
                encrypted_data = file.read()
            try:
                decrypted_data = f.decrypt(encrypted_data)
            except InvalidToken:
                print(f"Error: Invalid token for file {file_path}")
                continue
            with open(file_path, "wb") as file:
                file.write(decrypted_data)

if __name__ == "__main__":
    key_file_path = "/Users/nithya/Desktop/key.key"
    project_dir = "/Users/nithya/Desktop/file_upload_project-1"
    decrypt_project(key_file_path, project_dir)
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "file_upload_project.settings")
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)